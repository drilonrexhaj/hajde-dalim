// Hajde Dalim – lokale reale në Shtime (të dhëna publike: ARBK, Google/Evendo).
// Menutë janë çmime lokale të zakonshme kur lokali s’ka menu online.
// Oraret mund të ndryshojnë; kontrollo me telefon para se të shkosh.

const CATEGORIES = {
  restorant: { label: 'Restorant' },
  kafe:      { label: 'Kafe' },
  bar:       { label: 'Bar' },
  piceri:    { label: 'Piceri' },
  fastfood:  { label: 'Fast food' },
  embelsira: { label: 'Ëmbëlsira' },
  salle:     { label: 'Sallë eventesh' },
};

const HOME_TABS = [
  { key: 'sot',       label: 'Sot' },
  { key: 'ushqim',    label: 'Ushqim',    cats: ['restorant', 'piceri', 'fastfood'], emoji: '🍽️' },
  { key: 'kafe',      label: 'Kafe',      cats: ['kafe'], emoji: '☕' },
  { key: 'bar',       label: 'Bar',       cats: ['bar'], emoji: '🍸' },
  { key: 'ngjarje',   label: 'Ngjarje', emoji: '🎵' },
  { key: 'embelsira', label: 'Ëmbëlsira', cats: ['embelsira'], emoji: '🍰' },
  { key: 'salla',     label: 'Salla',     cats: ['salle'], emoji: '🎉' },
];

const FEATURES = {
  terrace:  'Taracë',
  live:     'Muzikë live',
  kids:     'Për fëmijë',
  sport:    'Ndeshje në TV',
  delivery: 'Dërgesa',
  wifi:     'Wi-Fi',
  parking:  'Parking',
};

const POST_TYPES = {
  offer: { label: 'Ofertë' },
  event: { label: 'Ngjarje' },
  menu:  { label: 'Menu e re' },
};

function weekHours(range, closedDay = null, overrides = {}) {
  const hours = [];
  for (let d = 0; d < 7; d++) hours.push(d === closedDay ? null : (overrides[d] || range));
  return hours;
}

function buildSeed(day) {
  const m = (section, items) => ({ section, items: items.map(([name, price]) => ({ name, price })) });
  const cafeMenu = [
    m('Kafe', [['Espresso', 0.8], ['Makiato', 1], ['Kapuçino', 1.3], ['Çaj', 0.8]]),
    m('Të ëmbla', [['Kroasan', 1], ['Copë torte', 1.5]]),
  ];
  const grillMenu = [
    m('Skarë', [['Qebapa (10 copë)', 3.5], ['Pleskavicë', 4], ['Pule në skarë', 4.5]]),
    m('Shtesa', [['Sallatë fshati', 2], ['Pije', 1]]),
  ];
  const pizzaMenu = [
    m('Pica', [['Margarita', 4], ['Capricciosa', 5], ['Tuna', 5.5], ['Speciale e shtëpisë', 6]]),
    m('Të tjera', [['Sallatë Cezar', 4], ['Pije 0.33l', 1]]),
  ];

  const venues = [
    {
      id: 'lisi', name: 'Restorant Lisi', category: 'restorant', price: 2,
      description: 'Restorant në Shtime me kuzhinë lokale. Hapet herët, i përshtatshëm për drekë dhe darkë.',
      address: 'Rr. Skender Salihaj, Shtime', phone: '+383 44 486 206',
      lat: 42.428475, lng: 21.038955,
      hours: weekHours('07:00-23:15'), features: ['terrace', 'parking', 'kids'],
      logo: 'images/logos/lisi.svg', photo: 'images/covers/lisi.jpg',
      menu: [
        m('Tradicionale', [['Flija (porcion)', 3.5], ['Tavë kosi', 5], ['Pite me spinaq', 2.5]]),
        m('Skarë', [['Qebapa (10 copë)', 3.5], ['Pleskavicë', 4], ['Mish i përzier për 2', 14]]),
        m('Pije', [['Dhallë', 1], ['Lëng i freskët', 1.5]]),
      ],
    },
    {
      id: 'druri', name: 'Restorant Druri', category: 'restorant', price: 2,
      description: 'Restorant-piceri në rrugën Komandant Kumanova. Kuzhinë kosovare dhe pica.',
      address: 'Rr. Komandant Kumanova 70, Shtime', phone: '+383 44 879 325',
      lat: 42.430909, lng: 21.042317,
      hours: weekHours('07:00-23:00'), features: ['terrace', 'parking', 'kids'],
      logo: 'images/logos/druri.svg', photo: 'images/covers/druri.jpg',
      menu: [
        m('Kuzhinë', [['Gjellë e ditës', 4], ['Tavë kosi', 5], ['Sallatë fshati', 2]]),
        ...pizzaMenu,
      ],
    },
    {
      id: 'select', name: 'Pizzeria Select', category: 'piceri', price: 2,
      description: 'Piceri në sheshin Ahmet Shtimja. Hapet nga mëngjesi deri vonë.',
      address: 'Sheshi Ahmet Shtimja, Shtime', phone: '+383 45 505 177',
      lat: 42.431969, lng: 21.039166,
      hours: weekHours('07:30-23:00', null, { 0: '08:00-23:00', 6: '08:00-23:00' }),
      features: ['delivery', 'wifi'],
      logo: 'images/logos/select.svg',
      menu: pizzaMenu,
    },
    {
      id: 'panino', name: 'Panino Pizzeria', category: 'piceri', price: 2,
      description: 'Piceri dhe sanduiçë në rrugën Zenun Beqa.',
      address: 'Rr. Zenun Beqa 44, Shtime', phone: '+383 45 366 282',
      lat: 42.43255, lng: 21.0399,
      hours: weekHours('10:00-23:00'), features: ['delivery', 'kids'],
      logo: 'images/logos/panino.svg',
      menu: [
        m('Pica', [['Margarita', 4], ['Capricciosa', 5], ['Panino speciale', 6]]),
        m('Sanduiçë', [['Panino me pulë', 3], ['Panino me suxhuk', 3]]),
      ],
    },
    {
      id: 'havana', name: 'Pizzeria Havana Caffe', category: 'piceri', price: 2,
      description: 'Piceri-kafe në rrugën Imer Devetaku.',
      address: 'Rr. Imer Devetaku, Shtime', phone: '+383 48 647 933',
      lat: 42.4322, lng: 21.03835,
      hours: weekHours('08:00-23:00'), features: ['wifi', 'terrace'],
      logo: 'images/logos/havana.svg',
      menu: pizzaMenu,
    },
    {
      id: 'xxl', name: 'Gjelltore & Grill XXL', category: 'fastfood', price: 1,
      description: 'Gjelltore dhe skarë në rrugën Skender Salihaj. Qebapa dhe mish në skarë.',
      address: 'Rr. Skender Salihaj, Shtime', phone: '+383 44 478 257',
      lat: 42.430989, lng: 21.041257,
      hours: weekHours('10:00-20:00'), features: ['delivery'],
      logo: 'images/logos/xxl.svg', photo: 'images/covers/xxl.jpg',
      menu: grillMenu,
    },
    {
      id: 'dardani', name: 'Gjelltore Dardani', category: 'fastfood', price: 1,
      description: 'Gjelltore dhe qebaptore. Qebapa, pleskavicë dhe gjellë e ditës.',
      address: 'Qendra, Shtime', phone: '+383 44 985 864',
      lat: 42.433246, lng: 21.038435,
      hours: weekHours('07:00-22:00'), features: ['delivery'],
      logo: 'images/logos/dardani.svg', photo: 'images/covers/dardani.jpg',
      menu: grillMenu,
    },
    {
      id: 'lounge99', name: '99 Lounge & Bar', category: 'bar', price: 2,
      description: 'Lounge në qendër: ushqim, koktej dhe muzikë. Hapur deri në orët e para të mëngjesit.',
      address: 'Qendra, Shtime', phone: '',
      lat: 42.432212, lng: 21.037458,
      hours: weekHours('10:00-03:00'), features: ['live', 'sport'],
      logo: 'images/logos/lounge99.svg', photo: 'images/covers/lounge99.jpg',
      menu: [
        m('Pije', [['Birrë 0.5l', 2], ['Mojito', 4], ['Aperol Spritz', 4.5]]),
        m('Ushqim', [['Nachos', 3.5], ['Burger', 4]]),
      ],
    },
    {
      id: 'npauze', name: "N'Pauzë Bar", category: 'bar', price: 2,
      description: 'Kafe-bar në qendër, nga mëngjesi deri në mesnatë. Kafe, pije dhe muzikë.',
      address: 'Qendra, Shtime', phone: '+383 43 971 981',
      lat: 42.432598, lng: 21.03797,
      hours: weekHours('07:00-00:00'), features: ['live', 'wifi'],
      logo: 'images/logos/npauze.svg', photo: 'images/covers/npauze.jpg',
      menu: [
        ...cafeMenu,
        m('Pije', [['Birrë 0.5l', 2], ['Pije freskuese', 1.5]]),
      ],
    },
    {
      id: 'river', name: 'River Bar', category: 'kafe', price: 1,
      description: 'Kafe në rrugën Imer Devetaku. Makiato, ëmbëlsira dhe taracë.',
      address: 'Rr. Imer Devetaku, Shtime', phone: '',
      lat: 42.432128, lng: 21.0385,
      hours: weekHours('07:00-23:00'), features: ['terrace', 'wifi'],
      logo: 'images/logos/river.svg', photo: 'images/covers/river.jpg',
      menu: cafeMenu,
    },
    {
      id: 'zara', name: 'Zara Coffee-Bar', category: 'kafe', price: 1,
      description: 'Kafe në Imer Devetaku. Mëngjes, makiato dhe ëmbëlsira.',
      address: 'Rr. Imer Devetaku, Shtime', phone: '+383 44 707 515',
      lat: 42.432528, lng: 21.037964,
      hours: weekHours('07:00-23:00'), features: ['wifi', 'terrace'],
      logo: 'images/logos/zara.svg', photo: 'images/covers/zara.jpg',
      menu: cafeMenu,
    },
    {
      id: 'stars', name: "Caffe Bar Star's", category: 'bar', price: 2,
      description: 'Bar në rrugën Tahir Sinani. Kafe ditën, pije në mbrëmje. Ndonjëherë muzikë live.',
      address: 'Rr. Tahir Sinani, Shtime', phone: '',
      lat: 42.432785, lng: 21.039906,
      hours: weekHours('07:00-23:00'), features: ['live', 'sport'],
      logo: 'images/logos/stars.svg', photo: 'images/covers/stars.jpg',
      menu: [
        ...cafeMenu,
        m('Pije', [['Birrë 0.5l', 2], ['Koktej', 4]]),
      ],
    },
    {
      id: 'konak', name: 'Konak Bar', category: 'kafe', price: 1,
      description: 'Kafe-bar në rrugën Adem Jashari. Hapet në mëngjes.',
      address: 'Rr. Adem Jashari 1, Shtime', phone: '',
      lat: 42.434838, lng: 21.043664,
      hours: weekHours('07:00-23:00'), features: ['terrace', 'wifi'],
      logo: 'images/logos/konak.svg',
      menu: cafeMenu,
    },
    {
      id: 'natyra', name: 'Sallë Natyra', category: 'salle', price: 3,
      description: 'Sallë dasmash dhe restorant. Dasma, fejesa dhe darka familjare.',
      address: 'Rr. Skender Salihu, Shtime', phone: '+383 44 475 568',
      lat: 42.421737, lng: 21.047787,
      hours: weekHours('08:00-00:00'), features: ['parking', 'live', 'kids'],
      logo: 'images/logos/natyra.svg', photo: 'images/covers/natyra.jpg',
      menu: [
        m('Paketa', [['Menu dasme (për person)', 18], ['Menu familjare (për person)', 12]]),
        m('Restorant', [['Qengj i pjekur', 9], ['Sallatë fshati', 2.5]]),
      ],
    },
    {
      id: 'kroni', name: 'Restaurant Kroni', category: 'restorant', price: 2,
      description: 'Restorant familjar dhe sallë në Pjetërshticë, komuna Shtime. Kuzhinë tradicionale.',
      address: 'Rr. Pashtriku 1998 nr. 300, Pjetërshticë, Shtime', phone: '+383 45 358 526',
      lat: 42.4485, lng: 21.0185,
      hours: weekHours('10:00-23:00'), features: ['parking', 'kids', 'terrace'],
      logo: 'images/logos/kroni.svg',
      menu: [
        m('Tradicionale', [['Flija', 3.5], ['Tavë kosi', 5], ['Qengj i pjekur', 9]]),
        m('Ahengje', [['Menu ahengu (për person)', 15]]),
      ],
    },
    {
      id: 'roots', name: 'Roots Retreat Center', category: 'salle', price: 3,
      description: 'Kompleks hotelier në fshatin Dugë, në zonën turistike Dugë–Karaqicë–Pjetërshticë. Natyrë, qëndrim dhe ahengje jashtë qytetit.',
      address: 'Fshati Dugë, Shtime 72000', phone: '',
      lat: 42.46069, lng: 20.92995,
      hours: weekHours('08:00-23:00'), features: ['parking', 'terrace', 'kids', 'live'],
      logo: 'images/logos/roots.svg', photo: 'images/covers/roots.svg',
      menu: [
        m('Qëndrimi', [['Dhoma (natë)', 40], ['Kabinë / vilë (natë)', 80]]),
        m('Ushqim', [['Mëngjes', 5], ['Drekë tradicionale', 8], ['Darkë për grup (për person)', 15]]),
      ],
    },
  ];

  venues.forEach(v => { v.pin = '1234'; });

  let n = 0;
  const p = (venueId, type, title, text, start, end, time = '', price = '') =>
    ({ id: 'demo-' + (++n), venueId, type, title, text, start: day(start), end: day(end), time, price, demo: true });

  const posts = [
    p('lounge99', 'event', 'Muzikë në lounge', 'Koktej dhe muzikë deri vonë. Hapur deri në 03:00.', 0, 0, '22:00'),
    p('stars', 'event', 'Mbrëmje me DJ', 'Në Caffe Bar Star’s. Hyrja e lirë.', 0, 0, '21:00'),
    p('lisi', 'offer', 'Menu e ditës', 'Supë + gjellë e ditës + sallatë. Pyet në lokal për gjellën e sotme.', 0, 0, '', '4,50 €'),
    p('select', 'offer', 'Pica e dytë me −50%', 'Vlen për pica të njëjta. Merr me vete ose ha aty.', 0, 0, '', '−50%'),
    p('zara', 'offer', 'Makiato + kroasan', 'Çdo mëngjes deri në 11:00.', 0, 6, '', '1,50 €'),
    p('xxl', 'offer', 'Qebapa + pije', 'Porcioni i qebapave me pije.', 0, 0, '', '4 €'),
    p('dardani', 'offer', 'Menu studenti', 'Qebapa ose burger + patate + pije.', 0, 30, '', '3,50 €'),
    p('npauze', 'offer', 'Happy hour', 'Pije me çmim të reduktuar, 17–19.', 0, 13, '17–19'),
    p('river', 'menu', 'Ëmbëlsirat e javës', 'Torta dhe kroasan të freskët çdo mëngjes.', -1, 6),
    p('natyra', 'event', 'Dita e hapur për çiftet', 'Shikoni sallën dhe menunë e dasmave.', 5, 5, '17:00'),
    p('kroni', 'offer', 'Drekë familjare', 'Në Pjetërshticë, për fundjavë.', 2, 4, '', ''),
    p('druri', 'event', 'Ndeshje në TV', 'Ejani me shoqëri. Pyet për orarin e ndeshjes.', 3, 3, '20:45'),
    p('roots', 'event', 'Fundjavë në natyrë', 'Roots Retreat Center, fshati Dugë. Qëndrim në natyrë, jashtë qytetit.', 2, 3, '12:00'),
  ];

  const stats = {};
  venues.forEach((v, i) => {
    stats[v.id] = { views: 90 + (i * 41) % 220, calls: 8 + (i * 5) % 24, directions: 6 + (i * 7) % 20, saves: 4 + (i * 3) % 16 };
  });

  return { version: 3, seededOn: day(0), venues, posts, stats, favorites: [], session: null };
}
