'use strict';

/* ============================================================
   Hajde Dalim – prototip (pa server, të dhënat ruhen në shfletues)
   ============================================================ */

const STORE_KEY = 'hajdeDalim_v3';
const SHTIME = { lat: 42.4331, lng: 21.0397 };
const CAT_COLOR = {
  restorant: '#1f4d40', kafe: '#6b3f2a', bar: '#3d2454', piceri: '#8a3a1a',
  fastfood: '#7a2e2e', embelsira: '#8a4a62', salle: '#1e3a5f',
};
const DAYS = ['e diel', 'e hënë', 'e martë', 'e mërkurë', 'e enjte', 'e premte', 'e shtunë'];
const MONTHS = ['janar', 'shkurt', 'mars', 'prill', 'maj', 'qershor', 'korrik', 'gusht', 'shtator', 'tetor', 'nëntor', 'dhjetor'];
const MONTHS_SHORT = ['Jan', 'Shk', 'Mar', 'Pri', 'Maj', 'Qer', 'Kor', 'Gus', 'Sht', 'Tet', 'Nën', 'Dhj'];
const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0]; // e hënë → e diel

/* ---------- Ikona (vija të thjeshta) ---------- */
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
  pin: '<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  back: '<path d="m15 18-6-6 6-6"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
  nav: '<path d="M3 11 22 2l-9 19-2-8z"/>',
  chev: '<path d="m9 6 6 6-6 6"/>',
  dot: '<circle cx="12" cy="12" r="5"/>',
};
const icon = (name, cls = '') =>
  `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;

/* ---------- Data & orë ---------- */
const pad = n => String(n).padStart(2, '0');
const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const todayISO = () => toISO(new Date());
function dayOffset(n) { const d = new Date(); d.setDate(d.getDate() + n); return toISO(d); }
function shiftISO(iso, n) { const d = parseISO(iso); d.setDate(d.getDate() + n); return toISO(d); }
const daysBetween = (a, b) => Math.round((parseISO(b) - parseISO(a)) / 86400000);
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const shortDate = iso => { const d = parseISO(iso); return `${d.getDate()} ${MONTHS[d.getMonth()]}`; };

function dateLabel(iso) {
  if (iso === todayISO()) return 'sot';
  if (iso === dayOffset(1)) return 'nesër';
  const d = parseISO(iso);
  return `${DAYS[d.getDay()]}, ${shortDate(iso)}`;
}

// "vetëm sot", "deri nesër", "deri më 8 nëntor", "nga 5 nëntor"
function periodLabel(p) {
  const t = todayISO();
  if (p.start > t) return p.start === p.end ? dateLabel(p.start) : 'nga ' + shortDate(p.start);
  if (p.end === t) return 'vetëm sot';
  if (p.end === dayOffset(1)) return 'deri nesër';
  return 'deri më ' + shortDate(p.end);
}

/* ---------- Ruajtja ---------- */
function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const s = JSON.parse(raw);
      if (s && s.version === 3) {
        // Zhvendos datat e postimeve demo që prototipi të ketë gjithmonë përmbajtje "Sot".
        const diff = daysBetween(s.seededOn, todayISO());
        if (diff !== 0) {
          s.posts.forEach(p => { if (p.demo) { p.start = shiftISO(p.start, diff); p.end = shiftISO(p.end, diff); } });
          s.seededOn = todayISO();
        }
        const seed = buildSeed(dayOffset);
        const seedById = Object.fromEntries(seed.venues.map(v => [v.id, v]));
        s.venues.forEach(v => {
          if (typeof v.lat !== 'number' || typeof v.lng !== 'number') {
            const src = seedById[v.id];
            v.lat = src ? src.lat : SHTIME.lat;
            v.lng = src ? src.lng : SHTIME.lng;
          }
        });
        seed.venues.forEach(sv => {
          if (!s.venues.some(v => v.id === sv.id)) s.venues.push(sv);
        });
        seed.posts.forEach(sp => {
          if (!s.posts.some(p => p.id === sp.id)) s.posts.push(sp);
        });
        if (seed.stats.roots && !s.stats.roots) s.stats.roots = seed.stats.roots;
        return s;
      }
    }
  } catch (e) { /* të dhëna të prishura → rifillo */ }
  return buildSeed(dayOffset);
}

let state = loadState();
function save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ } }
save();

const ui = { homeTab: 'sot', flags: new Set(), search: '', mapOpen: false };
const isStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;
const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
let installEvent = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  installEvent = e;
  const slot = document.getElementById('install-slot');
  if (slot) slot.innerHTML = installBanner();
});

/* ---------- Ndihmës ---------- */
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const venueById = id => state.venues.find(v => v.id === id);
const catLabel = v => CATEGORIES[v.category]?.label || '';
const euro = n => Number(n).toFixed(2).replace('.', ',') + ' €';
const statsOf = id => (state.stats[id] ||= { views: 0, calls: 0, directions: 0, saves: 0 });
const initial = name => esc((name.trim()[0] || '?').toUpperCase());

function parseRange(r) {
  if (!r) return null;
  const toM = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
  const [a, b] = r.split('-');
  return { o: toM(a), c: toM(b), open: a, close: b };
}

function openInfo(v, now = new Date()) {
  const mins = now.getHours() * 60 + now.getMinutes();
  const d = now.getDay();
  const prev = parseRange(v.hours[(d + 6) % 7]);
  if (prev && prev.c <= prev.o && mins < prev.c) return { open: true, until: prev.close };
  const t = parseRange(v.hours[d]);
  if (t) {
    const overnight = t.c <= t.o;
    if (mins >= t.o && (overnight || mins < t.c)) return { open: true, until: t.close };
    if (mins < t.o) return { open: false, opens: 'sot në ' + t.open };
  }
  return { open: false, opens: null };
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Mirëmëngjes';
  if (h < 17) return 'Mirëdita';
  return 'Mirëmbrëma';
}

function statusLine(v) {
  const i = openInfo(v);
  return i.open
    ? `<span class="status"><i class="sdot"></i><b>Hapur</b><span>deri ${i.until}</span></span>`
    : `<span class="status closed"><i class="sdot"></i><b>Mbyllur</b>${i.opens ? `<span>hapet ${i.opens.replace('sot në ', '')}</span>` : ''}</span>`;
}

const isActiveOn = (p, date) => p.start <= date && date <= p.end;
const byTime = (a, b) => (a.time || '99').localeCompare(b.time || '99');
const byDate = (a, b) => a.start.localeCompare(b.start) || byTime(a, b);

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

/* ---------- Komponentë ---------- */
const chip = (action, val, label, on) =>
  `<button class="chip ${on ? 'on' : ''}" data-action="${action}" data-val="${val}">${label}</button>`;

const empty = text => `<div class="empty">${text}</div>`;
const streetOf = v => v.address.replace(/,?\s*Shtime\s*$/i, '');
const coverTone = v => CAT_COLOR[v.category] || '#1a6b78';

function coverBox(v, badge = '', extraPhoto = '') {
  const src = extraPhoto || v.photo;
  const photo = src ? `<img class="cover-photo" src="${esc(src)}" alt="">` : '';
  const mark = v.logo
    ? `<img class="cover-logo" src="${esc(v.logo)}" alt="">`
    : `<span class="cover-letter">${initial(v.name)}</span>`;
  return `<div class="cover" style="--c:${coverTone(v)}">${photo}${mark}${badge}</div>`;
}

function fileToData(input, max = 900) {
  const file = input?.files?.[0];
  if (!file) return Promise.resolve('');
  return new Promise(resolve => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.78));
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(''); };
    img.src = url;
  });
}

function photoField(name, label, current = '') {
  return `
    <label>${label} <span class="opt">(një foto)</span>
      <input type="file" name="${name}" accept="image/*">
      ${current ? `<img class="upload-preview" src="${esc(current)}" alt="">` : '<img class="upload-preview" hidden alt="">'}
    </label>`;
}

function openBadge(v) {
  const i = openInfo(v);
  return i.open
    ? `<span class="badge on">Hapur · ${i.until}</span>`
    : `<span class="badge">Mbyllur</span>`;
}

function postRow(p, mode = 'date') {
  const v = venueById(p.venueId);
  if (!v) return '';
  let badge, sub;
  if (mode === 'time') {
    badge = p.time ? `<span class="badge time">${esc(p.time)}</span>` : `<span class="badge time">Sot</span>`;
    sub = `${esc(v.name)} · ${catLabel(v)}`;
  } else {
    const d = parseISO(p.start < todayISO() ? todayISO() : p.start);
    badge = `<span class="badge time">${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}</span>`;
    sub = [p.time ? 'Ora ' + esc(p.time) : '', esc(v.name)].filter(Boolean).join(' · ');
  }
  return `
    <a class="v-row" href="#/vend/${v.id}">
      ${coverBox(v, badge, p.photo)}
      <div class="v-body"><h3>${esc(p.title)}</h3><p>${sub}</p></div>
    </a>`;
}

function offerRow(p) {
  const v = venueById(p.venueId);
  if (!v) return '';
  const right = p.price || p.time || '';
  return `
    <a class="offer-row" href="#/vend/${v.id}">
      <div>
        <span class="kicker">${esc(POST_TYPES[p.type]?.label || 'Ofertë')}</span>
        <h3>${esc(p.title)}</h3>
        <p>${esc(v.name)}</p>
      </div>
      ${right ? `<b>${esc(right)}</b>` : ''}
    </a>`;
}

function offerCard(p, onVenuePage = false) {
  const v = venueById(p.venueId);
  if (!v) return '';
  const right = p.price || p.time || '';
  const tag = onVenuePage ? 'div' : 'a';
  const sub = onVenuePage ? (p.text || periodLabel(p)) : v.name;
  return `
    <${tag} class="d-card" ${onVenuePage ? '' : `href="#/vend/${v.id}"`}>
      ${coverBox(v, '', p.photo)}
      <div class="v-body">
        <h3>${esc(p.title)}</h3>
        ${sub ? `<p>${esc(sub)}</p>` : ''}
        ${right ? `<b class="price">${esc(right)}</b>` : ''}
      </div>
    </${tag}>`;
}

function venueRow(v) {
  return `
    <a class="v-row" href="#/vend/${v.id}">
      ${coverBox(v)}
      <div class="v-body">
        <h3>${esc(v.name)}</h3>
        <p>${catLabel(v)} · ${esc(streetOf(v))}</p>
        ${statusLine(v)}
      </div>
    </a>`;
}

function venueCard(v) {
  return `
    <a class="v-card" href="#/vend/${v.id}">
      ${coverBox(v, openBadge(v))}
      <div class="v-body">
        <h3>${esc(v.name)}</h3>
        <p>${catLabel(v)} · ${esc(streetOf(v))}</p>
      </div>
    </a>`;
}

function tonightCard(p) {
  const v = venueById(p.venueId);
  if (!v) return '';
  return `
    <a class="e-card" href="#/vend/${v.id}">
      ${coverBox(v, p.time ? `<span class="badge time">${esc(p.time)}</span>` : '', p.photo)}
      <div class="v-body">
        <h3>${esc(p.title)}</h3>
        <p>${esc(v.name)}</p>
      </div>
    </a>`;
}

function installBanner() {
  if (isStandalone) return '';
  if (installEvent) {
    return `<button type="button" class="install-card" data-action="install">Shto Hajde Dalim në telefon</button>`;
  }
  if (isIOS) {
    return `<p class="install-hint">Në iPhone: shtype <b>Ndaj</b> → <b>Shto në ekranin kryesor</b> që të hapet si aplikacion.</p>`;
  }
  return '';
}

function pageHead(title, sub = '', backBtn = false) {
  return `
    <header class="page-head">
      ${backBtn ? `<button class="circle-btn" data-action="back" aria-label="Kthehu">${icon('back')}</button>` : ''}
      <h1>${title}</h1>
      ${sub ? `<p class="muted">${sub}</p>` : ''}
    </header>`;
}

/* ---------- BALLINA ---------- */
function viewHome() {
  const tab = HOME_TABS.find(t => t.key === ui.homeTab) || HOME_TABS[0];
  if (tab.key !== 'sot') {
    return `
      <header class="page-head">
        <button class="circle-btn" data-action="home-tab" data-val="sot" aria-label="Kthehu">${icon('back')}</button>
        <h1>${tab.label}</h1>
        <p class="muted">Hapur dalin të parët.</p>
      </header>
      ${tab.key === 'ngjarje' ? eventsList() : categoryList(tab)}`;
  }
  return homeFeed();
}

function homeFeed() {
  const t = todayISO();
  const tonight = state.posts.filter(p => p.type === 'event' && isActiveOn(p, t)).sort(byTime);
  const offers = state.posts.filter(p => p.type !== 'event' && isActiveOn(p, t))
    .sort((a, b) => (a.type === 'menu') - (b.type === 'menu'));
  const venues = [...state.venues].sort((a, b) => openInfo(b).open - openInfo(a).open || a.name.localeCompare(b.name));
  const openN = venues.filter(v => openInfo(v).open).length;
  const cats = HOME_TABS.filter(x => x.key !== 'sot');

  const open = venues.filter(v => openInfo(v).open);

  return `
    <header class="home-hero">
      <div class="home-hero-top">
        <p class="loc">${icon('pin')} Shtime</p>
        <a class="circle-btn" href="#/kerko" aria-label="Kërko">${icon('search')}</a>
      </div>
      <h1>Çka ka sonte<br>në Shtime?</h1>
      <p>Ushqim, kafe, bar e ngjarje nga vetë lokalet.</p>
    </header>

    <div class="chips home-cats">
      <button type="button" class="chip on">Sot</button>
      ${cats.map(c => `<button type="button" class="chip" data-action="home-tab" data-val="${c.key}">${c.label}</button>`).join('')}
    </div>

    <section class="section">
      <div class="section-head">
        <h2>Sonte</h2>
        <button class="link" data-action="home-tab" data-val="ngjarje">Të gjitha</button>
      </div>
      ${tonight.length
        ? `<div class="v-stack">${tonight.map(p => postRow(p, 'time')).join('')}</div>`
        : empty('Sonte s’ka ngjarje të shpallura.')}
    </section>

    ${offers.length ? `
    <section class="section">
      <h2>Ofertat e ditës</h2>
      <div class="v-stack">${offers.map(offerRow).join('')}</div>
    </section>` : ''}

    <section class="section">
      <div class="section-head">
        <h2>Hapur tani</h2>
        <a class="link" href="#/kerko">${openN === 1 ? '1 lokal' : openN + ' lokale'}</a>
      </div>
      ${open.length
        ? `<div class="v-stack">${open.slice(0, 4).map(venueRow).join('')}</div>`
        : empty('Asnjë lokal i hapur në këtë orë. Shiko ofertat, ose kërko.')}
    </section>

    <a class="biz-note" href="#/profili">Ke lokal? <u>Hyr si biznes</u></a>
    <div id="install-slot">${installBanner()}</div>`;
}

function eventsList() {
  const t = todayISO();
  const events = state.posts.filter(p => p.type === 'event' && p.end >= t).sort(byDate);
  return `
    <section class="section">
      ${events.length ? `<div class="v-stack">${events.map(p => postRow(p, 'date')).join('')}</div>` : empty('Nuk ka ngjarje të planifikuara.')}
    </section>`;
}

function categoryList(tab) {
  const list = state.venues.filter(v => tab.cats.includes(v.category));
  list.sort((a, b) => openInfo(b).open - openInfo(a).open);
  return `
    <section class="section">
      ${list.length ? `<div class="v-stack">${list.map(venueCard).join('')}</div>` : empty('Ende asnjë lokal në këtë kategori.')}
    </section>`;
}

/* ---------- KËRKO ---------- */
function filteredVenues() {
  const q = norm(ui.search.trim());
  return state.venues.filter(v => {
    for (const fl of ui.flags) {
      if (fl === 'open' ? !openInfo(v).open : !v.features.includes(fl)) return false;
    }
    if (q) {
      const hay = norm([v.name, v.description, catLabel(v), v.address,
        ...v.menu.flatMap(s => [s.section, ...s.items.map(i => i.name)])].join(' '));
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function searchResults() {
  const list = filteredVenues();
  return list.length
    ? `<p class="results-meta">${list.length} ${list.length === 1 ? 'lokal' : 'lokale'}</p><div class="v-stack">${list.map(venueRow).join('')}</div>`
    : empty('Asgjë nuk u gjet. Provo një fjalë tjetër ose hiq filtrat.');
}

function viewSearch() {
  return `
    <header class="search-head">
      <button class="circle-btn" data-action="back" aria-label="Kthehu">${icon('back')}</button>
      <div class="search-input">${icon('search')}<input id="search" type="search" placeholder="Picë, makiato, flija…" value="${esc(ui.search)}" autocomplete="off"></div>
    </header>
    <div class="chips-wrap"><div class="chips">
      ${chip('flag', 'open', 'Hapur tani', ui.flags.has('open'))}
      ${['terrace', 'live', 'delivery'].map(fl => chip('flag', fl, FEATURES[fl], ui.flags.has(fl))).join('')}
    </div></div>
    <div id="results" class="section">${searchResults()}</div>`;
}

/* ---------- FAQJA E LOKALIT ---------- */
function viewVenue(id) {
  const v = venueById(id);
  if (!v) return notFound();
  const t = todayISO();
  const mine = state.posts.filter(p => p.venueId === id && p.end >= t).sort(byDate);
  const offers = mine.filter(p => p.type !== 'event');
  const events = mine.filter(p => p.type === 'event');
  const saved = state.favorites.includes(id);
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${v.name}, ${v.address}, Kosovo`)}`;
  const today = new Date().getDay();

  return `
    <div class="hero cover" style="--c:${coverTone(v)}">
      ${v.photo ? `<img class="cover-photo" src="${esc(v.photo)}" alt="">` : ''}
      <button class="circle-btn ghost-btn" data-action="back" aria-label="Kthehu">${icon('back')}</button>
      ${v.logo ? `<img class="cover-logo hero-logo" src="${esc(v.logo)}" alt="">` : `<span class="cover-letter">${initial(v.name)}</span>`}
      <span class="hero-cat">${esc(catLabel(v))}</span>
      <button class="circle-btn ghost-btn save ${saved ? 'on' : ''}" data-action="fav" data-id="${v.id}" aria-label="${saved ? 'Hiqe nga të ruajturat' : 'Ruaje'}">${icon('bookmark')}</button>
    </div>

    <section class="venue-title">
      <h1>${esc(v.name)}</h1>
      <div class="meta">${statusLine(v)}</div>
      ${v.description ? `<p class="desc">${esc(v.description)}</p>` : ''}
      <div class="actions">
        ${v.phone ? `<a class="btn primary" href="tel:${esc(v.phone.replace(/\s/g, ''))}" data-action="track" data-kind="calls" data-id="${v.id}">${icon('phone')} Thirr</a>` : ''}
        <a class="btn outline" href="${mapsUrl}" target="_blank" rel="noopener" data-action="track" data-kind="directions" data-id="${v.id}">${icon('nav')} Navigo</a>
      </div>
    </section>

    ${offers.length ? `
    <section class="section">
      <h2>Ofertat aktive</h2>
      <div class="v-stack">${offers.map(p => offerCard(p, true)).join('')}</div>
    </section>` : ''}

    ${events.length ? `
    <section class="section">
      <h2>Ngjarje të ardhshme</h2>
      <div class="v-stack">${events.map(p => postRow(p, 'date')).join('')}</div>
    </section>` : ''}

    <section class="section">
      <h2>Menu</h2>
      ${v.menu.length ? `<div class="list-card">${v.menu.map(s => `
        ${v.menu.length > 1 ? `<div class="list-sec">${esc(s.section)}</div>` : ''}
        ${s.items.map(i => `<div class="list-row"><span>${esc(i.name)}</span><b>${euro(i.price)}</b></div>`).join('')}`).join('')}
      </div>` : empty('Menuja nuk është shtuar ende.')}
    </section>

    <section class="section">
      <h2>Orari</h2>
      <div class="list-card">
        ${WEEK_ORDER.map(d => `
          <div class="list-row ${d === today ? 'today' : ''}">
            <span>${cap(DAYS[d])}</span>
            <span>${v.hours[d] ? v.hours[d].replace('-', ' – ') : 'Mbyllur'}</span>
          </div>`).join('')}
      </div>
      <p class="muted small info-line">${esc(v.address)} · ${esc(v.phone)}</p>
      ${v.features.length ? `<div class="tags">${v.features.map(f => `<span class="tag">${FEATURES[f]}</span>`).join('')}</div>` : ''}
    </section>`;
}

function mapVenues() {
  const list = state.venues.filter(v => !ui.mapOpen || openInfo(v).open);
  list.sort((a, b) => openInfo(b).open - openInfo(a).open || a.name.localeCompare(b.name));
  return list;
}

function pickCard(v) {
  return `
    <a class="pick-card" href="#/vend/${v.id}">
      ${coverBox(v)}
      <div class="v-body">
        <h3>${esc(v.name)}</h3>
        <p>${catLabel(v)} · ${esc(streetOf(v))}</p>
        ${statusLine(v)}
      </div>
    </a>`;
}

/* ---------- HARTA ---------- */
function viewMap() {
  const list = mapVenues();
  return `
    <div class="map-screen">
      <header class="map-head">
        <p class="eyebrow">Shtime</p>
        <h1>Harta</h1>
        <div class="map-tools">
          ${chip('map-open', 'open', 'Hapur tani', ui.mapOpen)}
          <span class="count">${list.length} ${list.length === 1 ? 'lokal' : 'lokale'}</span>
        </div>
      </header>
      <div class="map-wrap">
        <div id="map" class="map" role="application" aria-label="Harta e lokaleve në Shtime"></div>
        <div class="map-zoom">
          <button type="button" class="circle-btn" data-zoom="in" aria-label="Zmadho">+</button>
          <button type="button" class="circle-btn" data-zoom="out" aria-label="Zvogëlo">−</button>
        </div>
      </div>
      <div id="map-pick" class="map-pick"></div>
      <section class="map-list">
        <h2>Lokalet</h2>
        ${list.length ? `<div class="v-stack">${list.map(venueRow).join('')}</div>` : empty('Asnjë lokal hapur tani.')}
      </section>
    </div>`;
}

function mountMap() {
  const el = document.getElementById('map');
  if (!el) return;
  if (typeof L === 'undefined') {
    el.innerHTML = '<p class="muted small" style="padding:16px">Harta ka nevojë për internet herën e parë.</p>';
    return;
  }
  const list = mapVenues().filter(v => typeof v.lat === 'number' && typeof v.lng === 'number');
  const map = L.map(el, {
    scrollWheelZoom: false,
    zoomControl: false,
    attributionControl: false,
  }).setView([SHTIME.lat, SHTIME.lng], 15);
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
  }).addTo(map);

  const bounds = [];
  const markers = {};
  list.forEach(v => {
    const pin = L.divIcon({
      className: 'pin',
      html: v.logo
        ? `<span class="pin-dot pin-logo"><img src="${esc(v.logo)}" alt=""></span>`
        : `<span class="pin-dot" style="background:${CAT_COLOR[v.category] || 'var(--green)'}">${initial(v.name)}</span>`,
      iconSize: [34, 34],
      iconAnchor: [17, 17],
    });
    const marker = L.marker([v.lat, v.lng], { icon: pin, title: v.name }).addTo(map);
    marker.on('click', () => {
      Object.values(markers).forEach(m => m.getElement()?.classList.remove('on'));
      marker.getElement()?.classList.add('on');
      const slot = document.getElementById('map-pick');
      if (slot) {
        slot.innerHTML = pickCard(v);
        slot.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    });
    markers[v.id] = marker;
    bounds.push([v.lat, v.lng]);
  });
  if (bounds.length) map.fitBounds(bounds, { padding: [36, 36], maxZoom: 15 });
  el.closest('.map-wrap')?.querySelectorAll('[data-zoom]').forEach(btn => {
    btn.addEventListener('click', () => (btn.dataset.zoom === 'in' ? map.zoomIn() : map.zoomOut()));
  });
  setTimeout(() => map.invalidateSize(), 80);
}

/* ---------- RUAJTUR ---------- */
function viewSaved() {
  const list = state.favorites.map(venueById).filter(Boolean);
  return `
    ${pageHead('Të ruajtura', 'Lokalet që i do afër.')}
    <section class="section">
      ${list.length ? `<div class="v-stack">${list.map(venueCard).join('')}</div>` : `${empty('Ruaj lokalet që i do.')}<a class="btn primary full" href="#/">Shiko çka ka sonte</a>`}
    </section>`;
}

/* ---------- PROFILI & BIZNESET ---------- */
function profileFields(v = {}) {
  const firstHours = (v.hours && v.hours.find(Boolean)) || '08:00-23:00';
  const [open, close] = firstHours.split('-');
  const closedDay = v.hours ? v.hours.findIndex(h => !h) : -1;
  const feats = v.features || [];
  return `
    <div class="form-block">
      <p class="form-kicker">Lokali</p>
      <label>Emri<input name="name" required maxlength="50" value="${esc(v.name || '')}" placeholder="p.sh. Kafe Qendra"></label>
      <div class="row2">
        <label>Lloji<select name="category">${Object.entries(CATEGORIES).map(([k, c]) =>
          `<option value="${k}" ${v.category === k ? 'selected' : ''}>${c.label}</option>`).join('')}</select></label>
        <label>Çmimet<select name="price">${['Të lira', 'Mesatare', 'Të larta'].map((l, i) =>
          `<option value="${i + 1}" ${(v.price || 1) === i + 1 ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      </div>
      <label>Përshkrimi i shkurtër<textarea name="description" rows="3" maxlength="250" placeholder="Çka e bën të veçantë?">${esc(v.description || '')}</textarea></label>
      ${photoField('logo', 'Logo', v.logo || '')}
      ${photoField('photo', 'Foto e lokalit', v.photo || '')}
    </div>
    <div class="form-block">
      <p class="form-kicker">Kontakti</p>
      <label>Telefoni <span class="opt">(opsionale)</span><input name="phone" type="tel" value="${esc(v.phone || '')}" placeholder="+383 44 123 456"></label>
      <label>Adresa<input name="address" required maxlength="80" value="${esc(v.address || '')}" placeholder="Rruga ..., Shtime"></label>
    </div>
    <div class="form-block">
      <p class="form-kicker">Orari</p>
      <div class="row3">
        <label>Hapet<input type="time" name="open" value="${open}" required></label>
        <label>Mbyllet<input type="time" name="close" value="${close}" required></label>
        <label>Pushim<select name="closedDay"><option value="-1">Asnjë</option>${WEEK_ORDER.map(d =>
          `<option value="${d}" ${closedDay === d ? 'selected' : ''}>${cap(DAYS[d])}</option>`).join('')}</select></label>
      </div>
    </div>
    <div class="form-block">
      <p class="form-kicker">Çka ofron?</p>
      <fieldset class="checks">
        ${Object.entries(FEATURES).map(([k, label]) =>
          `<label class="check"><input type="checkbox" name="features" value="${k}" ${feats.includes(k) ? 'checked' : ''}><span>${label}</span></label>`).join('')}
      </fieldset>
    </div>`;
}

function readProfile(form) {
  const fd = new FormData(form);
  const closedDay = Number(fd.get('closedDay'));
  return {
    name: fd.get('name').trim(),
    category: fd.get('category'),
    price: Number(fd.get('price')),
    phone: fd.get('phone').trim(),
    address: fd.get('address').trim(),
    description: fd.get('description').trim(),
    hours: weekHours(`${fd.get('open')}-${fd.get('close')}`, closedDay >= 0 ? closedDay : null),
    features: fd.getAll('features'),
  };
}

function viewProfileLanding() {
  return `
    <header class="page-head">
      <h1>Biznes</h1>
      <p class="muted">Hyr ose hap një faqe të re për lokalin.</p>
    </header>
    <form class="panel" data-form="login">
      <h3>Hyr</h3>
      <label>Lokali<select name="id">${state.venues.map(v => `<option value="${v.id}">${esc(v.name)}</option>`).join('')}</select></label>
      <label>PIN<input name="pin" type="password" inputmode="numeric" maxlength="4" required placeholder="••••"></label>
      <button class="btn primary full">Hyr</button>
      <p class="hint">Demo: PIN <b>1234</b></p>
    </form>
    <p class="biz-note">Lokal i ri? <a href="#/profili/regjistro"><u>Regjistrohu</u></a></p>
    <div id="install-slot">${installBanner()}</div>
    <div class="center"><button class="link muted-link" data-action="reset">Rivendos demo</button></div>`;
}

function viewRegister() {
  return `
    ${pageHead('Regjistro lokalin', 'Emri, telefoni, orari. Pastaj PIN.', true)}
    <form class="panel" data-form="register">
      ${profileFields()}
      <div class="form-block">
        <p class="form-kicker">Hyrja</p>
        <label>PIN me 4 shifra<input name="pin" class="pin-input" type="password" inputmode="numeric" pattern="\\d{4}" maxlength="4" required placeholder="••••"></label>
      </div>
      <button class="btn primary full">Krijo faqen</button>
    </form>`;
}

const DASH_TABS = { paneli: 'Sot', posto: 'Posto', menuja: 'Menu', faqja: 'Faqja' };

function viewDashboard(v, tab) {
  if (tab === 'te-dhenat') tab = 'faqja';
  if (tab === 'postimet' || tab === 'statistikat' || !DASH_TABS[tab]) tab = 'paneli';
  const body = { paneli: dashHome, posto: dashPost, menuja: dashMenu, faqja: dashProfile }[tab](v);
  return `
    <header class="dash-head">
      <div class="dash-top">
        <h1>${esc(v.name)}</h1>
        <button type="button" class="link muted-link" data-action="logout">Dil</button>
      </div>
      <div class="meta">${statusLine(v)} · <a href="#/vend/${v.id}">Shiko faqen</a></div>
    </header>
    <nav class="dash-nav">${Object.entries(DASH_TABS).map(([k, l]) =>
      `<a href="#/profili${k === 'paneli' ? '' : '/' + k}" class="${k === tab ? 'on' : ''}">${l}</a>`).join('')}
    </nav>
    ${body}`;
}

function dashHome(v) {
  const t = todayISO();
  const s = statsOf(v.id);
  const mine = state.posts.filter(p => p.venueId === v.id);
  const live = mine.filter(p => isActiveOn(p, t));
  return `
    <div class="stats">
      <div class="stat"><b>${s.views}</b><span>Shikime</span></div>
      <div class="stat"><b>${s.calls}</b><span>Thirrje</span></div>
      <div class="stat"><b>${s.directions}</b><span>Navigime</span></div>
    </div>
    <a class="btn primary full" href="#/profili/posto">Posto diçka</a>
    <section class="section">
      <div class="section-head">
        <h2>Aktive (${live.length})</h2>
      </div>
      ${live.length ? `<div class="v-stack">${live.map(adminPostCard).join('')}</div>` : empty('Asgjë aktive. Posto nga skeda Posto.')}
    </section>
    ${(() => {
      const others = mine.filter(p => !isActiveOn(p, t)).sort((a, b) => b.start.localeCompare(a.start));
      return others.length ? `<section class="section"><h2>Më parë</h2><div class="v-stack">${others.map(adminPostCard).join('')}</div></section>` : '';
    })()}`;
}

function dashPost() {
  const t = todayISO();
  return `
    <form class="panel post-form" data-form="post">
      <div class="segmented">${Object.entries(POST_TYPES).map(([k, pt], i) =>
        `<label><input type="radio" name="type" value="${k}" ${i === 0 ? 'checked' : ''}><span>${pt.label}</span></label>`).join('')}</div>
      <label>Titulli<input name="title" required maxlength="60" placeholder="p.sh. Menu e ditës"></label>
      <label>Detaje <span class="opt">(opsionale)</span><textarea name="text" rows="2" maxlength="300"></textarea></label>
      <div class="row2">
        <label>Çmimi<input name="price" maxlength="12" placeholder="4,50 €"></label>
        <label>Ora<input type="time" name="time"></label>
      </div>
      <div class="span-row">
        <button type="button" class="chip on" data-action="post-span" data-val="0">Sot</button>
        <button type="button" class="chip" data-action="post-span" data-val="1">Deri nesër</button>
        <button type="button" class="chip" data-action="post-span" data-val="6">Këtë javë</button>
      </div>
      <div class="row2">
        <label>Nga<input type="date" name="start" value="${t}" min="${t}" required></label>
        <label>Deri<input type="date" name="end" value="${t}" min="${t}" required></label>
      </div>
      ${photoField('photo', 'Foto e postimit')}
      <button class="btn primary full">Posto</button>
    </form>`;
}

function adminPostCard(p) {
  const t = todayISO();
  const [cls, label] = p.end < t ? ['expired', 'Skaduar'] : p.start > t ? ['soon', 'Së shpejti'] : ['live', 'Aktive'];
  return `
    <div class="panel post-admin">
      <div class="row-between">
        <span class="muted small">${POST_TYPES[p.type].label} · ${periodLabel(p)}</span>
        <span class="pill ${cls}">${label}</span>
      </div>
      <h3>${esc(p.title)}${p.price ? ` <span class="muted">· ${esc(p.price)}</span>` : ''}</h3>
      ${p.photo ? `<img class="post-thumb" src="${esc(p.photo)}" alt="">` : ''}
      ${p.text ? `<p class="muted small">${esc(p.text)}</p>` : ''}
      <button class="link danger" data-action="del-post" data-id="${p.id}">Fshije</button>
    </div>`;
}

function dashMenu(v) {
  return `
    <form class="panel" data-form="menu-item">
      <h3>Shto në menu</h3>
      <label>Seksioni<input name="section" list="sections" required placeholder="Kafe, Pica, Pije…"></label>
      <datalist id="sections">${v.menu.map(s => `<option value="${esc(s.section)}">`).join('')}</datalist>
      <div class="row2">
        <label>Emri<input name="name" required maxlength="60" placeholder="Makiato"></label>
        <label>Çmimi (€)<input name="price" type="number" step="0.05" min="0" required placeholder="1.00"></label>
      </div>
      <button class="btn primary full">Shto</button>
    </form>
    <div class="section">
        ${v.menu.length ? `<div class="panel list-card">${v.menu.map((s, si) => `
        <div class="list-sec">${esc(s.section)}</div>
        ${s.items.map((i, ii) => `
          <div class="list-row">
            <span>${esc(i.name)}</span>
            <span class="row-end"><b>${euro(i.price)}</b><button class="x-btn" data-action="del-item" data-s="${si}" data-i="${ii}" aria-label="Hiqe">×</button></span>
          </div>`).join('')}`).join('')}
      </div>` : empty('Menuja është bosh. Shto artikullin e parë sipër.')}
    </div>`;
}

function dashProfile(v) {
  return `
    <p class="muted lead">Këto i shohin klientët te faqja jote.</p>
    <form class="panel" data-form="profile">
      ${profileFields(v)}
      <button class="btn primary full">Ruaj ndryshimet</button>
    </form>`;
}

function viewProfile(sub) {
  const v = state.session && venueById(state.session);
  if (v) return viewDashboard(v, sub);
  return sub === 'regjistro' ? viewRegister() : viewProfileLanding();
}

function notFound() {
  return `${pageHead('Faqja nuk u gjet')}${empty('<a href="#/">Kthehu te ballina</a>')}`;
}

/* ---------- Router ---------- */
function paintNav(active) {
  const items = [
    { tab: 'ballina', href: '#/', icon: 'home', label: 'Sot' },
    { tab: 'harta', href: '#/harta', icon: 'pin', label: 'Harta' },
    { tab: 'ruajtura', href: '#/ruajtura', icon: 'bookmark', label: 'Ruajtur' },
  ];
  if (state.session) items.push({ tab: 'profili', href: '#/profili', icon: 'user', label: 'Biznes' });
  const bar = document.getElementById('tabbar');
  bar.style.gridTemplateColumns = `repeat(${items.length}, 1fr)`;
  bar.innerHTML = items.map(n => `<a href="${n.href}" data-tab="${n.tab}">${icon(n.icon)}<span>${n.label}</span></a>`).join('');
  bar.querySelectorAll('a').forEach(el => el.classList.toggle('active', el.dataset.tab === active));
}

function route() {
  const [r, a] = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean).map(decodeURIComponent);
  return { r, a };
}

function render() {
  const { r, a } = route();
  let html, tab = 'ballina';
  switch (r) {
    case undefined: html = viewHome(); break;
    case 'kerko': html = viewSearch(); break;
    case 'vend': tab = ''; html = viewVenue(a); break;
    case 'harta': tab = 'harta'; html = viewMap(); break;
    case 'ruajtura': tab = 'ruajtura'; html = viewSaved(); break;
    case 'profili': tab = 'profili'; html = viewProfile(a); break;
    default: tab = ''; html = notFound();
  }
  document.getElementById('view').innerHTML = html;
  paintNav(tab);
  document.querySelector('.app').classList.toggle('detail', r === 'vend' || r === 'kerko' || (r === 'profili' && a === 'regjistro'));
  if (r === 'harta') mountMap();
}

function onNavigate() {
  const { r, a } = route();
  if (r === 'vend' && venueById(a)) { statsOf(a).views++; save(); }
  render();
  window.scrollTo(0, 0);
  if (r === 'kerko') document.getElementById('search')?.focus();
}

/* ---------- Veprimet ---------- */
const actions = {
  'home-tab': (el, e) => {
    e.preventDefault();
    ui.homeTab = el.dataset.val;
    if (location.hash !== '#/' && location.hash !== '') location.hash = '#/';
    else { render(); window.scrollTo(0, 0); }
  },
  flag: el => { const f = el.dataset.val; ui.flags.has(f) ? ui.flags.delete(f) : ui.flags.add(f); render(); },
  'post-span': el => {
    const n = Number(el.dataset.val);
    const start = document.querySelector('input[name="start"]');
    const end = document.querySelector('input[name="end"]');
    if (start && end) { start.value = todayISO(); end.value = dayOffset(n); }
    document.querySelectorAll('[data-action="post-span"]').forEach(b => b.classList.toggle('on', b === el));
  },
  'map-open': () => { ui.mapOpen = !ui.mapOpen; render(); },
  'open-now': () => { ui.flags.add('open'); location.hash = '#/kerko'; },
  back: () => { history.length > 1 ? history.back() : (location.hash = '#/'); },
  fav: el => {
    const id = el.dataset.id;
    const i = state.favorites.indexOf(id);
    if (i >= 0) { state.favorites.splice(i, 1); statsOf(id).saves = Math.max(0, statsOf(id).saves - 1); toast('U hoq nga të ruajturat'); }
    else { state.favorites.push(id); statsOf(id).saves++; toast('U ruajt'); }
    save(); render();
  },
  track: el => { statsOf(el.dataset.id)[el.dataset.kind]++; save(); }, // linku vazhdon normalisht
  logout: () => { state.session = null; save(); location.hash = '#/profili'; render(); toast('Dole nga paneli'); },
  'del-post': el => {
    if (!confirm('Ta fshij këtë postim?')) return;
    state.posts = state.posts.filter(p => p.id !== el.dataset.id);
    save(); render(); toast('Postimi u fshi');
  },
  'del-item': el => {
    const v = venueById(state.session);
    const s = v.menu[Number(el.dataset.s)];
    s.items.splice(Number(el.dataset.i), 1);
    if (!s.items.length) v.menu.splice(Number(el.dataset.s), 1);
    save(); render();
  },
  install: async () => {
    if (!installEvent) return;
    installEvent.prompt();
    await installEvent.userChoice;
    installEvent = null;
    render();
  },
  reset: () => {
    if (!confirm('Të fshihen të gjitha ndryshimet dhe të rikthehen të dhënat demo?')) return;
    state = buildSeed(dayOffset); save(); ui.homeTab = 'sot'; location.hash = '#/'; render(); toast('Të dhënat demo u rikthyen');
  },
};

const forms = {
  login: f => {
    const fd = new FormData(f);
    const v = venueById(fd.get('id'));
    if (!v || v.pin !== fd.get('pin')) return toast('PIN i gabuar');
    state.session = v.id; save();
    location.hash = '#/profili';
    render();
    toast(`Mirë se erdhe, ${v.name}`);
  },
  register: async f => {
    const profile = readProfile(f);
    const pin = new FormData(f).get('pin');
    const slug = norm(profile.name).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'lokal';
    const id = `${slug}-${Date.now().toString(36)}`;
    const [logo, photo] = await Promise.all([fileToData(f.logo, 256), fileToData(f.photo, 900)]);
    state.venues.push({ id, ...profile, pin, menu: [], lat: SHTIME.lat, lng: SHTIME.lng, logo, photo });
    statsOf(id);
    state.session = id; save();
    location.hash = '#/profili';
    render();
    toast('Faqja u krijua. Posto ofertën e parë.');
  },
  post: async f => {
    const fd = new FormData(f);
    const start = fd.get('start'), end = fd.get('end');
    if (end < start) return toast('Data “Deri më” duhet të jetë pas datës së fillimit');
    const photo = await fileToData(f.photo, 900);
    state.posts.push({
      id: 'p-' + Date.now().toString(36), venueId: state.session, type: fd.get('type'),
      title: fd.get('title').trim(), text: fd.get('text').trim(), price: fd.get('price').trim(),
      start, end, time: fd.get('time') || '', photo, createdAt: new Date().toISOString(),
    });
    save();
    location.hash = '#/profili';
    render();
    toast(start === todayISO() ? 'U postua. Tani shfaqet në ballinë.' : 'U postua. Shfaqet ' + dateLabel(start) + '.');
  },
  'menu-item': f => {
    const fd = new FormData(f);
    const v = venueById(state.session);
    const name = fd.get('section').trim();
    let s = v.menu.find(x => norm(x.section) === norm(name));
    if (!s) { s = { section: name, items: [] }; v.menu.push(s); }
    s.items.push({ name: fd.get('name').trim(), price: Number(fd.get('price')) });
    save(); render(); toast('U shtua në menu');
  },
  profile: async f => {
    const v = venueById(state.session);
    Object.assign(v, readProfile(f));
    const [logo, photo] = await Promise.all([fileToData(f.logo, 256), fileToData(f.photo, 900)]);
    if (logo) v.logo = logo;
    if (photo) v.photo = photo;
    save(); render(); toast('Ndryshimet u ruajtën');
  },
};

document.addEventListener('click', e => {
  const el = e.target.closest('[data-action]');
  if (el && actions[el.dataset.action]) actions[el.dataset.action](el, e);
});

document.addEventListener('submit', e => {
  const f = e.target.closest('form[data-form]');
  if (!f || !forms[f.dataset.form]) return;
  e.preventDefault();
  Promise.resolve(forms[f.dataset.form](f));
});

document.addEventListener('input', e => {
  if (e.target.id === 'search') {
    ui.search = e.target.value;
    document.getElementById('results').innerHTML = searchResults();
  }
});

document.addEventListener('change', e => {
  if (e.target.type !== 'file' || !e.target.files?.[0]) return;
  const label = e.target.closest('label');
  const preview = label?.querySelector('.upload-preview');
  if (!preview) return;
  preview.hidden = false;
  preview.src = URL.createObjectURL(e.target.files[0]);
});

window.addEventListener('hashchange', onNavigate);
onNavigate();

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => { /* offline / file:// */ });
}
