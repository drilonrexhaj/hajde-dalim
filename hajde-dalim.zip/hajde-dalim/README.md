# Hajde Dalim – Shtime

A working web app for finding where to eat, drink and go out in Shtime. Businesses sign up for free and post offers, events and new menus.

It runs in the browser and can be installed on a phone like a native app (PWA).

## How to run it

You need a local web server (required for the map, install prompt, and offline cache). From this folder:

```bash
python3 -m http.server 8080
```

Then open **http://localhost:8080** on your computer, or `http://YOUR-IP:8080` on your phone (same Wi-Fi).

Double-clicking `index.html` still works for a quick look, but the map tiles and “Add to Home Screen” need the server.

### Install on a phone

- **Android (Chrome):** open the URL → menu → **Install app**, or tap **Shto Hajde Dalim në telefon** if it appears.
- **iPhone (Safari):** Share → **Add to Home Screen**.

## Pages

- **Ballina (Home):** "Çka ka sonte në Shtime?" with events tonight, daily offers and this week. Tabs: Sot, Ushqim, Kafe, Bar, Ngjarje, Ëmbëlsira, Salla
- **Search (🔍):** search venues and menus, with filters (open now, terrace, live music…)
- **Venue page:** Thirr (call), Navigo (directions), active offers, upcoming events, menu, opening hours
- **Harta (Map):** OpenStreetMap of Shtime with a pin per venue
- **Ruajtur (Saved):** saved venues
- **Profili (Profile):** business registration and login (demo PIN: `1234`), then the panel: Posto, Postimet, Menuja, Të dhënat, Statistikat

## Limitations

- The venues are fictional demo data, stored only in this browser (`localStorage`).
- The PIN is a demo, not real security. Statistics are counted only on this device.
- Map pins for demo venues are approximate locations in Shtime, not official addresses.
- There is no shared backend yet: each phone has its own copy of the data.
