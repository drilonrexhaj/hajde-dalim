#!/usr/bin/env python3
"""Generate PWA PNG icons (no third-party deps)."""
import os, struct, zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "icons")
os.makedirs(OUT, exist_ok=True)

GREEN = (31, 77, 64, 255)
RUST = (194, 66, 28, 255)
WHITE = (255, 255, 255, 255)
CREAM = (243, 245, 242, 255)


def write_png(path, w, h, pixels):
    raw = bytearray()
    i = 0
    for _y in range(h):
        raw.append(0)
        raw.extend(pixels[i : i + w * 4])
        i += w * 4
    def chunk(tag, data):
        crc = zlib.crc32(tag + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", crc)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(chunk(b"IHDR", ihdr))
        f.write(chunk(b"IDAT", zlib.compress(bytes(raw), 9)))
        f.write(chunk(b"IEND", b""))


def lerp(a, b, t):
    return a + (b - a) * t


def draw_icon(size, maskable=False):
    px = bytearray(size * size * 4)
    pad = int(size * 0.18) if maskable else 0
    inner = size - pad * 2
    cx = size / 2
    # pin sits in upper 70%
    pin_cx = cx
    pin_cy = size * 0.42
    r = inner * 0.22
    tip_y = size - pad - inner * 0.12

    def setp(x, y, c):
        if 0 <= x < size and 0 <= y < size:
            i = (y * size + x) * 4
            px[i : i + 4] = bytes(c)

    def inside_round_rect(x, y, rad):
        nx = min(max(x, rad), size - 1 - rad)
        ny = min(max(y, rad), size - 1 - rad)
        dx, dy = x - nx, y - ny
        return dx * dx + dy * dy <= rad * rad

    rad = int(size * 0.22)
    for y in range(size):
        for x in range(size):
            if maskable or inside_round_rect(x, y, rad):
                setp(x, y, GREEN)
            else:
                setp(x, y, (0, 0, 0, 0))

    # teardrop pin
    for y in range(size):
        for x in range(size):
            dx = x - pin_cx
            dy = y - pin_cy
            in_circle = dx * dx + dy * dy <= r * r
            # triangle from circle bottom to tip
            t = (y - (pin_cy + r * 0.2)) / (tip_y - (pin_cy + r * 0.2) + 1e-6)
            half = lerp(r * 0.95, 0, max(0, min(1, t)))
            in_tri = (pin_cy + r * 0.15) <= y <= tip_y and abs(dx) <= half
            if in_circle or in_tri:
                setp(x, y, RUST if y > pin_cy + r * 0.55 else WHITE)

    # inner hole
    hole = r * 0.38
    for y in range(size):
        for x in range(size):
            dx = x - pin_cx
            dy = y - pin_cy
            if dx * dx + dy * dy <= hole * hole:
                setp(x, y, GREEN if maskable else GREEN)

    return px


for size in (180, 192, 512):
    write_png(os.path.join(OUT, f"icon-{size}.png"), size, size, draw_icon(size, False))

write_png(os.path.join(OUT, "icon-512-maskable.png"), 512, 512, draw_icon(512, True))
print("icons written to", OUT)
